/**
 * Copyright (c) 2013-Now http://jeesite.com All rights reserved.
 */
package com.jeesite.modules.config.web;

import org.springframework.context.annotation.Configuration;

/**
 * Servlet 配置
 * @author ThinkGem
 * @version 2017年11月30日
 */
@Configuration
public class ServletConfig {
	
}
